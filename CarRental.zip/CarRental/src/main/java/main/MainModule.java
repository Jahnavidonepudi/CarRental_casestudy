package main;

import java.sql.Date;
import java.util.List;
import java.util.Scanner;

import dao.*;
import entity.model.Car;
import entity.model.Customer;
import entity.model.Lease;
import exception.LeaseNotFoundException;
import util.DBConnUtil;

public class MainModule {
public static void main(String[] args) throws LeaseNotFoundException {
ICarLeaseRepository carLeaseRepository = new ICarLeaseRepositoryImpl();


        
        Scanner sc = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Car Rental System Menu:");
            System.out.println("1. Add Customer");
            System.out.println("2. Add Car");
            System.out.println("3. Create Lease");
            System.out.println("4. Return Car");
            System.out.println("5. Record Payment");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            switch (choice) {
                case 1:
                    // Add Customer
                    System.out.print("Enter First Name: ");
                    String firstName = sc.next();
                    System.out.print("Enter Last Name: ");
                    String lastName = sc.next();
                    System.out.print("Enter Email: ");
                    String email = sc.next();
                    System.out.print("Enter Phone Number: ");
                    String phoneNumber = sc.next();
                    carLeaseRepository.addCustomer(new Customer(0, firstName, lastName, email, phoneNumber));
                    System.out.println("Customer added");
                    break;

                case 2:
                    // Add Car
                    System.out.print("Enter Make: ");
                    String make = sc.next();
                    System.out.print("Enter Model: ");
                    String model = sc.next();
                    System.out.print("Enter Year: ");
                    int year = sc.nextInt();
                    System.out.print("Enter Daily Rate: ");
                    double dailyRate = sc.nextDouble();
                    System.out.print("Enter Status (available/notAvailable): ");
                    String status = sc.next();
                    System.out.print("Enter Passenger Capacity: ");
                    int passengerCapacity = 0;                
                    double engineCapacity = sc.nextDouble(); 
                    carLeaseRepository.addCar(new Car(0, make, model, year, dailyRate, status, passengerCapacity, engineCapacity));
                    System.out.println("Car added");
                    break;

                case 3:
                    // Create Lease
                    System.out.print("Enter Customer ID: ");
                    int customerID = sc.nextInt();
                    System.out.print("Enter Car ID: ");
                    int carID = sc.nextInt();
                    System.out.print("Enter Start Date (yyyy-mm-dd): ");
                    String startDateStr = sc.next();
                    System.out.print("Enter End Date (yyyy-mm-dd): ");
                    String endDateStr = sc.next();  
                    Date startDate = java.sql.Date.valueOf(startDateStr);
                    Date endDate = java.sql.Date.valueOf(endDateStr);
                    System.out.print("Enter type: ");
                    String type = sc.next();
                    
                    carLeaseRepository.createLease(customerID, carID, startDate, endDate);
                   System.out.println("Lease created");
                    break;

                case 4:
                    // Return Car
                    System.out.print("Enter Lease ID: ");
                    int leaseID = sc.nextInt();
                    carLeaseRepository.returnCar(leaseID);
                    System.out.println("Car returned");
                    break;

                
                case 5:
                    // Record Payment
                	System.out.print("Enter Lease ID: ");
                    int leaseIDForPayment = sc.nextInt();
                    System.out.print("Enter Amount: "); 
                    double amount = sc.nextDouble();
                    System.out.println("Payment Recorded");
                    break;

                case 6:
                    // Exit
                    System.out.println("Exiting...");
                    
                    break;

                default:
                    System.out.println("Invalid choice. Please try again.");
                    break;
            }
        } while (choice != 6);
        
        sc.close();
    }
}
