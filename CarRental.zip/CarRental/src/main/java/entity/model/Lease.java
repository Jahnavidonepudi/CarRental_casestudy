package entity.model;

import java.util.Date;

public class Lease {
    private int leaseID;
    private int carID;
    private int customerID;
    private int startDate;
    private int endDate;
    private String type;

    public Lease() {}

    public Lease(int leaseID, int vehicleID, int customerID, int startDate, int endDate, String type) {
        this.leaseID = leaseID;
        this.carID = carID;
        this.customerID = customerID;
        this.startDate = startDate;
        this.endDate = endDate;
        this.type = type;
    }

    public int getLeaseID() { return leaseID; }
    public void setLeaseID(int leaseID) { this.leaseID = leaseID; }

    public int getCarID() { return carID; }
    public void setCarID(int carID) { this.carID = carID; }

    public int getCustomerID() { return customerID; }
    public void setCustomerID(int customerID) { this.customerID = customerID; }

    public int getStartDate() { return startDate; }
    public void setStartDate(int i) { this.startDate = i; }

    public int getEndDate() { return endDate; }
    public void setEndDate(int i) { this.endDate = i; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }
}
