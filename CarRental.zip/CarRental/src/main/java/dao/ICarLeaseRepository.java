package dao;

import entity.model.Car;
import entity.model.Customer;
import entity.model.Lease;
import exception.CarNotFoundException;

import java.util.List;
import java.util.Date;

public interface ICarLeaseRepository {
    // Car Management
    void addCar(Car car);
    void removeCar(int carID);
    List<Car> listAvailableCars();
    List<Car> listRentedCars();
    Car findCarById(int carID) throws CarNotFoundException;

    // Customer Management
    void addCustomer(Customer customer);
    void removeCustomer(int customerID);
    List<Customer> listCustomers();
    Customer findCustomerById(int customerID) ;

    // Lease Management
    Lease createLease(int customerID, int carID, Date startDate, Date endDate);
    void returnCar(int leaseID);
     List<Lease> listActiveLeases();
     List<Lease> listLeaseHistory();

    // Payment Handling
     
    void recordPayment(double amount);
	void recordPayment(Lease lease, double amount);
	void addCar(Lease lease);
	
}
