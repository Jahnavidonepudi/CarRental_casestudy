package util;

import java.sql.Connection;
import java.sql.DriverManager;

import util. DBConnUtil;

public class DBConnUtil {
	
	
	
	private static Connection conn ;
		
		private   DBConnUtil() {
	     try {
	            
	            Class.forName("com.mysql.cj.jdbc.Driver");
	 
	           
	            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/carrental", "root", "Janu@4107");
	 
	            System.out.println("Connected to the database");
	           
	 
	        }
	        catch(Exception e)
	        {
	        	System.out.println(e);
	        }
	 
		}
	 
		public static Connection  getConnect()
		 {
			 DBConnUtil d1= new  DBConnUtil();
			 return conn;
			
		 }
		
	
		}
		
		
		
		
		
		
	
	


