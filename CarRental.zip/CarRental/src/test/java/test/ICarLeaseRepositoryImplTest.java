package test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import dao.ICarLeaseRepositoryImpl;
import entity.model.Customer;
import entity.model.Lease;
import entity.model.Car;
import exception.CustomerNotFoundException;
import exception.LeaseNotFoundException;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;



public class ICarLeaseRepositoryImplTest {

    private ICarLeaseRepositoryImpl repository;

    @BeforeEach
    public void setUp() {
        repository = new ICarLeaseRepositoryImpl();
    }

    @Test
    public void testAddCar() {

        Car car = new Car();
        car.setCarID(1);
        car.setMake("City");
        car.setModel("Honda");
        car.setYear(1999);
        car.setStatus("not available");
        car.setDailyRate(3000);
        car.setPassengerCapacity(5);
        car.setEngineCapacity(800);
        repository.addCar(car);

    }

    @Test
    public void testAddLease() {

        Lease lease = new Lease();
        lease.setLeaseID(100);
        lease.setCustomerID(11);
        lease.setCarID(1);
        lease.setStartDate(2021);
        lease.setEndDate(2022);
        repository.addCar(lease);

    }
    @Test
    public void testListActiveLeases() {

        repository.listActiveLeases();
    }
  

	@Test
    public void testGetLeaseBy() throws LeaseNotFoundException {

        repository.getLeaseBy(1);
    }

   

    
}